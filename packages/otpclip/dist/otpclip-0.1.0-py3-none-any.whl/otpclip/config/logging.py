import logging

from otpclip.config.env import environment
from shared.logging.logger import ClickEchoHandler

# HANDLER
log_handler = ClickEchoHandler()
log_handler.setLevel(getattr(logging, environment.LOGGING_LEVEL))

# LOGGER
logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, environment.LOGGING_LEVEL))
logger.addHandler(log_handler)